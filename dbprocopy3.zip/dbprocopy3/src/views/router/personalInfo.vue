<template>
  <div class="user-profile" ref="scrollContainer" @wheel="handleWheel">
    <h2>用户信息</h2>
    <div v-if="loading" class="loading">
      <q-spinner color="primary" size="2em" />
      <p>加载中...</p>
    </div>
    <div v-else-if="error" class="error">
      <q-icon name="error" color="negative" size="2em" />
      <p>{{ error }}</p>
      <q-btn
        color="primary"
        label="重新加载"
        @click="fetchUserData"
        class="q-mt-sm"
      />
    </div>
    <div v-else-if="user" class="user-info" ref="userInfoSection">
      <div class="user-avatar">
        <q-avatar size="100px" color="primary" text-color="white">
          {{ user.name.charAt(0).toUpperCase() }}
        </q-avatar>
      </div>
      <div class="user-details">
        <p><strong>用户ID:</strong> {{ user.userId }}</p>
        <p><strong>用户名:</strong> {{ user.name }}</p>
        <p><strong>余额:</strong> ¥{{ user.money.toFixed(2) }}</p>
      </div>

      <div class="user-objects" ref="objectsSection">
        <h3>我的物品</h3>
        <div v-if="objectsLoading" class="loading">
          <q-spinner color="primary" size="1em" />
          <p>加载物品中...</p>
        </div>
        <div v-else-if="objectsError" class="error">
          <q-icon name="error" color="negative" size="1em" />
          <p>{{ objectsError }}</p>
          <q-btn
            color="primary"
            label="重试"
            @click="fetchUserObjects(user.userId)"
            class="q-mt-sm"
          />
        </div>
        <div v-else-if="objects && objects.length > 0" class="objects-list">
          <q-table
            :rows="objects"
            :columns="objectColumns"
            row-key="objectId"
            flat
            bordered
            hide-pagination
          >
            <template v-slot:no-data>
              <div class="no-data-in-table">
                <q-icon name="info" color="warning" size="1em" />
                <p>暂无物品数据</p>
              </div>
            </template>
          </q-table>
        </div>
        <div v-else class="no-data">
          <q-icon name="info" color="warning" size="1em" />
          <p>暂无物品</p>
        </div>
      </div>

      <div class="action-buttons" ref="actionSection">
        <q-btn
          color="negative"
          label="注销账号"
          @click="showLogoutConfirm"
          class="q-mr-md"
        />
        <q-btn
          color="primary"
          label="充值"
          @click="showRechargeDialog"
          class="q-mr-md"
        />
        <q-btn
          color="secondary"
          label="上传物品"
          @click="showUploadDialog"
        />
      </div>
    </div>
    <div v-else class="no-data">
      <q-icon name="info" color="warning" size="2em" />
      <p>未获取到用户数据</p>
    </div>

    <q-dialog v-model="rechargeDialog">
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">账户充值</div>
        </q-card-section>

        <q-card-section>
          <q-input
            v-model.number="rechargeAmount"
            type="number"
            label="充值金额"
            min="0"
            step="0.01"
          />
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="取消" color="primary" v-close-popup />
          <q-btn flat label="确认充值" color="primary" @click="handleRecharge" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <q-dialog v-model="uploadDialog">
      <q-card style="min-width: 400px">
        <q-card-section>
          <div class="text-h6">上传物品</div>
        </q-card-section>

        <q-card-section>
          <q-uploader
            url="/api/upload"
            label="选择文件"
            multiple
            :max-files="1"
            :max-file-size="10485760"
            accept=".jpg,.jpeg,.png,.pdf"
            @rejected="onRejected"
            @uploaded="onUploaded"
          />
        </q-card-section>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
export default {
  name: 'personalInfo',
  data () {
    return {
      user: null,
      loading: false,
      error: null,
      baseURL: process.env.VUE_APP_API_BASE_URL || 'http://localhost:8080',
      rechargeDialog: false,
      rechargeAmount: 0,
      uploadDialog: false,
      objects: [],
      objectsLoading: false,
      objectsError: null,
      objectColumns: [
        {
          name: 'objectId',
          required: true,
          label: '物品ID',
          align: 'left',
          field: row => row.objectId,
          sortable: true
        },
        {
          name: 'name',
          required: true,
          label: '物品名称',
          align: 'left',
          field: row => row.name,
          sortable: true
        },
        {
          name: 'type',
          label: '类型',
          align: 'left',
          field: row => row.type,
          sortable: true
        },
        {
          name: 'value',
          label: '价值',
          align: 'left',
          field: row => row.value,
          sortable: true
        }
      ],
      sections: [],
      currentSection: 0,
      isScrolling: false,
      scrollTimeout: null
    }
  },
  created () {
    this.fetchUserData()
  },
  mounted () {
    this.$nextTick(() => {
      this.sections = [
        this.$refs.userInfoSection,
        this.$refs.objectsSection,
        this.$refs.actionSection
      ]
    })

    window.addEventListener('keydown', this.handleKeyDown)
  },
  beforeDestroy () {
    window.removeEventListener('keydown', this.handleKeyDown)
  },
  methods: {
    getCookie (name) {
      const nameEQ = name + '='
      const ca = document.cookie.split(';')
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i]
        while (c.charAt(0) === ' ') c = c.substring(1, c.length)
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
      }
      return null
    },

    getUserId () {
      const cookieUserId = this.getCookie('user_id') || this.getCookie('userId')
      if (cookieUserId) return parseInt(cookieUserId)

      const sessionUserId = sessionStorage.getItem('user_id') || sessionStorage.getItem('userId')
      if (sessionUserId) return parseInt(sessionUserId)

      const localUserId = localStorage.getItem('user_id') || localStorage.getItem('userId')
      if (localUserId) return parseInt(localUserId)

      return null
    },

    async fetchUserData () {
      try {
        this.loading = true
        this.error = null

        const userId = this.getUserId()
        if (!userId) {
          throw new Error('无法获取用户ID，请先登录')
        }

        const response = await this.$axios({
          method: 'get',
          url: '/selectSingleUser',
          baseURL: this.baseURL,
          params: { userId: userId },
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }
        })

        if (response.data) {
          this.user = response.data
          localStorage.setItem('currentUser', JSON.stringify(response.data))
          this.fetchUserObjects(userId)
        } else {
          throw new Error('未获取到用户数据')
        }
      } catch (error) {
        console.error('获取用户信息失败:', error)
        this.error = `请求失败: ${error.message}`

        if (error.response) {
          if (error.response.status === 404) {
            this.error = '接口不存在，请检查路径是否正确'
          } else if (error.response.status === 500) {
            this.error = '服务器内部错误，请联系管理员'
          }
        }

        const cachedUser = localStorage.getItem('currentUser')
        if (cachedUser) {
          this.user = JSON.parse(cachedUser)
          this.error = '使用缓存数据: ' + this.error
        }
      } finally {
        this.loading = false
      }
    },

    async fetchUserObjects (userId) {
      try {
        this.objectsLoading = true
        this.objectsError = null
        this.objects = []

        const response = await this.$axios({
          method: 'get',
          url: '/showUserObject',
          baseURL: this.baseURL,
          params: { userId: userId },
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }
        })

        console.log('物品接口响应:', response.data)

        if (Array.isArray(response.data)) {
          this.objects = response.data
        } else if (response.data && response.data.data && Array.isArray(response.data.data)) {
          this.objects = response.data.data
        } else if (response.data && response.data.records && Array.isArray(response.data.records)) {
          this.objects = response.data.records
        } else {
          console.warn('意外的数据格式:', response.data)
          this.objects = []
        }

        console.log('处理后物品列表:', this.objects)
      } catch (error) {
        console.error('获取用户物品失败:', error)
        this.objectsError = `获取物品失败: ${error.message}`
        if (error.response) {
          if (error.response.status === 404) {
            this.objectsError = '接口不存在'
          } else if (error.response.status === 500) {
            this.objectsError = '服务器错误'
          }
        }
      } finally {
        this.objectsLoading = false
      }
    },

    showLogoutConfirm () {
      this.$q.dialog({
        title: '确认注销',
        message: '确定要注销当前账号吗？此操作将清除所有登录信息',
        cancel: true,
        persistent: true
      }).onOk(() => {
        this.logoutAccount()
      })
    },

    async logoutAccount () {
      try {
        await this.$axios.post('/api/logout')
        this.clearUserData()
        this.$router.push('/login')
      } catch (error) {
        console.error('注销失败:', error)
        this.$q.notify({
          type: 'negative',
          message: '注销失败: ' + (error.response?.data?.message || error.message)
        })
      }
    },

    clearUserData () {
      localStorage.removeItem('currentUser')
      sessionStorage.removeItem('user_id')
      sessionStorage.removeItem('userId')
      document.cookie = 'user_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;'
      document.cookie = 'userId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;'
    },

    showRechargeDialog () {
      this.rechargeAmount = 0
      this.rechargeDialog = true
    },

    async handleRecharge () {
      if (this.rechargeAmount <= 0) {
        this.$q.notify({
          type: 'warning',
          message: '请输入有效的充值金额'
        })
        return
      }

      try {
        this.$q.notify({
          type: 'positive',
          message: `成功充值 ¥${this.rechargeAmount.toFixed(2)}`
        })

        this.user.money += this.rechargeAmount
        localStorage.setItem('currentUser', JSON.stringify(this.user))

        this.rechargeDialog = false
      } catch (error) {
        console.error('充值失败:', error)
        this.$q.notify({
          type: 'negative',
          message: '充值失败: ' + (error.response?.data?.message || error.message)
        })
      }
    },

    showUploadDialog () {
      this.uploadDialog = true
    },

    onRejected (rejectedEntries) {
      this.$q.notify({
        type: 'negative',
        message: `文件 ${rejectedEntries[0].file.name} 不符合要求`,
        caption: '请上传jpg、jpeg、png或pdf文件，且大小不超过10MB'
      })
    },

    onUploaded (info) {
      const response = JSON.parse(info.xhr.response)
      this.$q.notify({
        type: 'positive',
        message: `文件 ${response.fileName} 上传成功`
      })
      this.uploadDialog = false
      this.fetchUserObjects(this.user.userId)
    },

    handleWheel (event) {
      if (this.isScrolling) {
        event.preventDefault()
        return
      }

      if (event.deltaY > 0) {
        this.nextSection()
      } else {
        this.prevSection()
      }

      event.preventDefault()
    },

    handleKeyDown (event) {
      if (event.key === 'ArrowDown') {
        this.nextSection()
        event.preventDefault()
      } else if (event.key === 'ArrowUp') {
        this.prevSection()
        event.preventDefault()
      }
    },

    nextSection () {
      if (this.currentSection < this.sections.length - 1) {
        this.currentSection++
        this.scrollToSection(this.currentSection)
      }
    },

    prevSection () {
      if (this.currentSection > 0) {
        this.currentSection--
        this.scrollToSection(this.currentSection)
      }
    },

    scrollToSection (index) {
      this.isScrolling = true

      this.sections[index].scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      })

      clearTimeout(this.scrollTimeout)
      this.scrollTimeout = setTimeout(() => {
        this.isScrolling = false
      }, 800)
    }
  }
}
</script>

<style scoped>
html {
  scroll-behavior: smooth
}

.user-profile {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  height: 100vh;
  overflow: hidden
}

.user-avatar {
  display: flex;
  justify-content: center;
  margin-bottom: 20px
}

.user-details {
  background: #f9f9f9;
  padding: 20px;
  border-radius: 6px;
  margin-bottom: 20px
}

.user-details p {
  margin: 10px 0;
  font-size: 16px;
  line-height: 1.6
}

.user-objects {
  margin-top: 30px;
  padding: 20px;
  background: #f5f5f5;
  border-radius: 6px
}

.user-objects h3 {
  margin-bottom: 15px;
  text-align: center
}

.loading, .error, .no-data {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px;
  text-align: center
}

.loading {
  color: #1976d2
}

.error {
  color: #c10015
}

.no-data {
  color: #ff9800
}

.q-avatar {
  font-size: 3rem
}

.action-buttons {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  padding-bottom: 50px
}

.no-data-in-table {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
  color: #ff9800
}

.user-info-section {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center
}

.objects-section {
  min-height: 100vh
}

.action-section {
  min-height: 50vh;
  display: flex;
  align-items: center;
  justify-content: center
}
</style>
