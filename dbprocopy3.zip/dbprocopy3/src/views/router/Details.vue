<template>
  <div class="detail-page-container"> <!-- 新增外层容器 -->
    <!-- 页面内容居中 -->
    <div class="detail-content-wrapper">
      <!-- 面包屑导航 -->
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>商品详情</el-breadcrumb-item>
      </el-breadcrumb>

      <!-- 详情卡片 -->
      <el-card class="detail-card">
        <template #header>
          <div class="card-header">
            <span>商品详情</span>
          </div>
        </template>
        <!-- 详情内容区域 -->
        <div class="detail-content">
          <!-- 图片展示 -->
          <div class="image-wrapper">
            <el-image
              :src="item.imageUrl"
              style="width: 350px; height: 350px;"
              :preview-src-list="[item.imageUrl]">
            </el-image>
          </div>

          <!-- 信息展示 -->
          <div class="info-wrapper">
            <h2 class="title">{{ item.name }}</h2>
            <div class="property-item">
              <span class="label">在售数量：</span>
              <span>{{ item.amo }}</span>
            </div>
            <div class="property-item">
              <span class="label">最低售价：</span>
              <span class="price">{{ item.min }} 元</span>
            </div>
            <div class="property-item">
              <span class="label">商品编号：</span>
              <span>{{ item.num }}</span>
            </div>
            <!-- 操作按钮 -->
            <div class="action-buttons">
              <el-button type="primary" size="medium">立即购买</el-button>
              <el-button type="info" size="medium" style="margin-left: 10px;">加入购物车</el-button>
            </div>
          </div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Detail',
  data () {
    return {
      item: {
        num: '',
        name: '黄狗之刃',
        amo: '10000',
        min: '2',
        imageUrl: 'https://picsum.photos/350/350?random=1' // 随机示例图片
      }
    }
  },
  mounted () {
    const id = this.$route.params.id
    this.fetchData(id)
  },
  methods: {
    fetchData (id) {
      // 模拟API请求（实际项目需替换为真实接口）
      setTimeout(() => {
        this.item.num = id
      }, 300)
    }
  }
}
</script>

<style scoped>
.detail-page-container {
  min-height: 100vh; /* 确保容器高度至少为屏幕高度 */
  background-color: #f5f7fa; /* 背景色 */
  padding: 40px 0; /* 上下内边距 */
}

.detail-content-wrapper {
  max-width: 1000px; /* 最大宽度 */
  margin: 0 auto; /* 水平居中 */
  padding: 0 20px; /* 左右内边距，防止内容紧贴边缘 */
}

.detail-card {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1); /* 轻微阴影 */
}

.card-header {
  font-size: 18px;
  font-weight: 500;
}

.detail-content {
  display: flex;
  flex-wrap: wrap; /* 允许内容在小屏幕上换行 */
  gap: 40px;
  padding: 30px;
}

.image-wrapper {
  border: 1px solid #ebeef5;
  border-radius: 4px;
  padding: 10px;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
}

.info-wrapper {
  flex: 1;
  min-width: 300px; /* 小屏幕下的最小宽度 */
}

.title {
  font-size: 24px;
  color: #333;
  margin-bottom: 25px;
  font-weight: 500;
}

.property-item {
  margin-bottom: 15px;
  font-size: 16px;
  color: #606266;
}

.label {
  font-weight: 500;
  color: #909399;
  display: inline-block;
  width: 80px; /* 统一标签宽度，使内容对齐 */
}

.price {
  color: #f56c6c;
  font-size: 18px;
  font-weight: 500;
}

.action-buttons {
  margin-top: 30px;
}
</style>
