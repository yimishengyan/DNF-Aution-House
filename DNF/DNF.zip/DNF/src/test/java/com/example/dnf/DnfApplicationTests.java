package com.example.dnf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DnfApplicationTests {

    @Test
    void contextLoads() {
    }

}
