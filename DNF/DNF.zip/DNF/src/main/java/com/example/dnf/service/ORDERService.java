package com.example.dnf.service;

import com.example.dnf.entity.Order;
import com.example.dnf.mapper.ORDERMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ORDERService {
    @Autowired
    ORDERMapper orderMapper;

    public String insertOrder(Order order) {
        int ret = orderMapper.insertOrder(order);
        return ret > 0 ? "交易成功" : "交易失败";
    }
}
