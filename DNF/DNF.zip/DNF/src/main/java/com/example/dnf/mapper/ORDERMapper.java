package com.example.dnf.mapper;

import com.example.dnf.entity.Order;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.springframework.web.bind.annotation.RestController;

public interface ORDERMapper {
    @Options(useGeneratedKeys = true, keyProperty = "orderId", keyColumn = "orderId")
    @Insert("INSERT INTO order (objectId, buyerId, sellerId, value) VALUES (#{objectId}, #{buyerId}, #{sellerId}, #{value})")
    public int insertOrder(Order order);
}
