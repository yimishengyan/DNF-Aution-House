// 滚动条样式
export const thumbStyle = {
  right: '5px',
  borderRadius: '5px',
  backgroundColor: '#616161',
  width: '5px'
}

export const thumbStyleOfMenu = {
  borderRadius: '5px',
  backgroundColor: 'rgba(144,147,153,0.9)',
  padding: '10px;',
  margin: '10px;',
  width: '3px'
}
