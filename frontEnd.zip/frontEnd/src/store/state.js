
const state = {
  role: '',
  routes: [],
  tagView: [],
  breadcrumbs: [],
  keepAliveList: []
}

export default state
