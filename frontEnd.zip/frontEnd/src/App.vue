<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
  @import "./assets/css/main.css";
  @import './assets/scss/transition.scss';
  @import "./assets/css/cimo.css";
</style>
