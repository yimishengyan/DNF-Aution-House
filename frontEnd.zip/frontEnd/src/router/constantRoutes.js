/**
 * 公共路由
 */
const constantRoutes = [
  {
    path: '/logon',
    name: 'Logon.vue',
    meta: {
      title: '登录'
    },
    component: () => import('@/views/logon/Logon.vue')
  },
  {
    path: '/Logon',
    name: 'Register.vue',
    component: () => import('@/views/logon/Register.vue')
  },
  {
    path: 'getting-started/ask',
    name: 'Details.vue',
    component: () => import('@/views/router/Details.vue')
  },
  {
    path: '/NoFound404',
    name: 'NoFound404',
    meta: {
      title: '404',
      icon: 'sentiment_dissatisfied',
      isHidden: true
    },
    component: () => import('@/components/404/NoFound404')
  },
  {
    path: '/Adlogon',
    name: 'AdLogon.vue',
    meta: {
      title: '登录'
    },
    component: () => import('@/views/logon/AdLogon.vue')
  },
  {
    path: '/AdLogon',
    name: 'AdRegister.vue',
    component: () => import('@/views/logon/AdRegister.vue')
  }
]

export default constantRoutes
