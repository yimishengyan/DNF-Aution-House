<template>
  <base-content>
    <div style="height: 100%; display: flex; flex-direction: column;">
      <div style="float: right; margin-top: 5px; margin-bottom: 5px; margin-right: 20px;">
        <el-input
          placeholder="Search"
          v-model="filter"
          suffix-icon="el-icon-search"
          clearable
        >
        </el-input>
      </div>

      <!-- 添加滚动容器 -->
      <div class="table-container">
        <el-table
          :data="filterData"
          :header-cell-style="{ background: '#f3a183', color: '#555' }"
          border
          style="width: 100%"
          height="100%"
        >
          <el-table-column prop="userId" label="用户ID" width="200">
          </el-table-column>
          <el-table-column prop="name" label="名字" width="250">
          </el-table-column>
          <el-table-column prop="password" label="密码" width="250">
          </el-table-column>
          <el-table-column prop="money" label="金额" width="300">
          </el-table-column>
          <el-table-column label="操作" width="300">
            <template slot-scope="scope">
              <el-button
                type="danger"
                size="mini"
                @click="handleDelete(scope.row)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </base-content>
</template>

<script>
export default {
  name: 'Admanage',
  data () {
    return {
      tableData: [],
      filter: ''
    }
  },
  computed: {
    filterData () {
      if (!this.filter) return this.tableData
      const filter = this.filter.toLowerCase()
      return this.tableData.filter(item => {
        return Object.values(item).some(value =>
          String(value).toLowerCase().includes(filter)
        )
      })
    }
  },
  methods: {
    handleDelete (user) {
      this.$confirm('确定要删除该用户吗?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 调用后端删除API - 传递完整的用户对象
        this.$axios.post('http://localhost:8080/deleteUser', user, {
          headers: {
            'Content-Type': 'application/json'
          }
        })
          .then(response => {
            if (response.data === '删除成功') {
              this.$message.success('删除成功')
              // 重新加载数据
              this.fetchData()
            } else {
              this.$message.error('删除失败：' + response.data)
            }
          })
          .catch(error => {
            console.error('删除失败:', error)
            this.$message.error('删除失败：' + error.message)
          })
      }).catch(() => {
        this.$message.info('已取消删除')
      })
    },

    fetchData () {
      this.$axios.get('http://localhost:8080/showUser')
        .then(res => {
          this.tableData = res.data
        })
        .catch(error => {
          console.error('获取用户数据失败:', error)
          this.$message.error('数据加载失败')
        })
    }
  },
  created () {
    this.fetchData()
  }
}
</script>

<style>
/* 添加表格容器样式 */
.table-container {
  flex: 1; /* 占据剩余空间 */
  overflow: hidden; /* 防止内容溢出 */
  position: relative;
}

.el-table {
  border-color: #ed9d09 !important;
  height: 100%; /* 关键：表格高度100% */
}

.el-table__body-wrapper {
  overflow-y: auto !important; /* 确保垂直滚动 */
  max-height: calc(100vh - 150px); /* 根据页面高度自适应 */
}

.el-table__body td,
.el-table__header-wrapper th {
  border-color: #f6aa08 !important;
}

/* 自定义滚动条样式 */
.el-table__body-wrapper::-webkit-scrollbar {
  width: 8px; /* 垂直滚动条宽度 */
  height: 8px; /* 水平滚动条高度 */
}

.el-table__body-wrapper::-webkit-scrollbar-thumb {
  border-radius: 4px;
  background-color: rgba(0, 0, 0, 0.3);
}

.el-table__body-wrapper::-webkit-scrollbar-track {
  border-radius: 4px;
  background-color: rgba(0, 0, 0, 0.1);
}
</style>
