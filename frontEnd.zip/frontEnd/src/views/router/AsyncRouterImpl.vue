<template>
  <base-content>
    <div style="height: 100%; display: flex; flex-direction: column;">
      <!-- 搜索框 -->
      <div style="float: right; margin: 5px 20px;">
        <el-input
          placeholder="搜索订单"
          v-model="filter"
          suffix-icon="el-icon-search"
          @clear="filter = ''"
          clearable
          style="width: 200px;"
        >
        </el-input>
      </div>

      <!-- 订单列表表格 -->
      <div class="table-container">
        <el-table
          :data="filteredOrders"
          border
          v-loading="orderLoading"
          style="width: 100%"
        >
          <el-table-column prop="orderId" label="订单号" width="180" align="center"></el-table-column>
          <el-table-column prop="objectName" label="物品名称" width="200" align="center"></el-table-column>
          <el-table-column prop="buyerName" label="买家姓名" width="180" align="center"></el-table-column>
          <el-table-column prop="sellerName" label="卖家姓名" width="180" align="center"></el-table-column>
          <el-table-column prop="value" label="交易金额" width="150" align="center">
            <template slot-scope="scope">
              ¥{{ scope.row.value.toFixed(2) }}
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </base-content>
</template>

<script>
// Cookie 读取函数
function getCookie (name) {
  const nameEQ = name + '='
  const ca = document.cookie.split(';')
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === ' ') c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

export default {
  name: 'AsyncRouterImpl',
  data () {
    return {
      filter: '',
      orderData: [],
      orderLoading: false
    }
  },
  computed: {
    // 过滤订单数据
    filteredOrders () {
      if (!this.filter) return this.orderData
      const filter = this.filter.toLowerCase()
      return this.orderData.filter(order => {
        return (
          String(order.order).toLowerCase().includes(filter) ||
          order.objectName.toLowerCase().includes(filter) ||
          order.buyerName.toLowerCase().includes(filter) ||
          order.sellerName.toLowerCase().includes(filter) ||
          String(order.value).toLowerCase().includes(filter)
        )
      })
    }
  },
  methods: {
    // 获取当前用户对象
    getCurrentUser () {
      const userId = getCookie('user_id')
      if (!userId) return null
      return {
        userId: parseInt(userId)
      }
    },

    // 获取订单数据
    fetchOrders () {
      const user = this.getCurrentUser()
      if (!user) {
        this.$message.error('请先登录')
        return
      }

      this.orderLoading = true

      this.$axios.post('http://localhost:8080/showOrder', user)
        .then(res => {
          this.orderData = res.data
        })
        .catch(error => {
          console.error('获取订单失败:', error)
          this.$message.error('获取订单失败')
        })
        .finally(() => {
          this.orderLoading = false
        })
    }
  },
  mounted () {
    // 页面加载时自动获取订单数据
    this.fetchOrders()
  }
}
</script>

<style>
.table-container {
  flex: 1;
  padding: 20px;
  overflow: auto;
}

.el-table th {
  background-color: #f3a183;
  color: #555;
  font-weight: bold;
}

.el-table__body td {
  border-color: #f6aa08 !important;
}
</style>
