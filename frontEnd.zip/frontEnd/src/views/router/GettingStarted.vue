<template>
  <base-content>
    <div style="height: 100%; display: flex; flex-direction: column;">
      <div style="float: right; margin-top: 5px; margin-bottom: 5px; margin-right: 20px;">
        <el-input
          placeholder="Search"
          v-model="filter"
          suffix-icon="el-icon-search"
          @clear="filter = ''"
          clearable
        >
        </el-input>
      </div>

      <!-- 添加滚动容器 -->
      <div class="table-container" ref="tableContainer">
        <el-table
          :data="filterData"
          :header-cell-style="{ background: '#f3a183', color: '#555' }"
          border
          height="100%"
        >
          <el-table-column prop="objectId" label="序号" width="200">
          </el-table-column>
          <el-table-column prop="name" label="名字" width="250">
          </el-table-column>
          <el-table-column prop="count" label="在售数量" width="250">
          </el-table-column>
          <el-table-column prop="value" label="最低售价" width="300">
          </el-table-column>
          <el-table-column label="操作" width="300">
            <template slot-scope="scope">
              <el-button @click="handleDetail(scope.row)">查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 添加详情弹窗 -->
      <el-dialog
        :title="`${selectedName} 的武器详情`"
        :visible.sync="detailDialogVisible"
        width="70%"
        center
      >
        <el-table :data="detailData" v-loading="detailLoading">
          <el-table-column prop="objectId" label="序号" width="100"></el-table-column>
          <el-table-column prop="name" label="武器名称" width="200"></el-table-column>
          <el-table-column prop="value" label="价钱" width="150"></el-table-column>
          <el-table-column prop="ownerId" label="拥有者ID" width="150"></el-table-column>
          <el-table-column label="操作" width="150">
            <template slot-scope="scope">
              <el-button type="primary" @click="handleBuy(scope.row)">购买</el-button>
            </template>
          </el-table-column>
        </el-table>
        <span slot="footer" class="dialog-footer">
          <el-button @click="detailDialogVisible = false">关 闭</el-button>
        </span>
      </el-dialog>
    </div>
  </base-content>
</template>

<script>
// Cookie 读取函数
function getCookie (name) {
  const nameEQ = name + '='
  const ca = document.cookie.split(';')
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === ' ') c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

export default {
  name: 'GettingStarted',
  data () {
    return {
      tableData: [],
      helloData: '',
      filter: '',
      type: 'weapon',
      autoScrollInterval: null,
      isMouseOverTable: false,

      // 详情弹窗相关数据
      detailDialogVisible: false,
      detailData: [],
      detailLoading: false,
      selectedName: '',

      // 购买相关数据
      buyerId: null,
      sellerId: null
    }
  },
  computed: {
    filterData () {
      if (!this.filter) return this.tableData
      const filter = this.filter.toLowerCase()
      return this.tableData.filter(item => {
        return Object.values(item).some(value =>
          String(value).toLowerCase().includes(filter)
        )
      })
    }
  },
  methods: {
    // 获取当前用户ID的方法（从Cookie获取）
    getCurrentUserId () {
      const userId = getCookie('user_id')
      return userId ? parseInt(userId) : null
    },

    // 检查用户是否登录（从Cookie检查）
    isLoggedIn () {
      return getCookie('isLoggedIn') === 'true'
    },

    handleDetail (row) {
      this.selectedName = row.name
      this.detailDialogVisible = true
      this.fetchDetailData(row.name)
    },

    // 获取详情数据
    fetchDetailData (name) {
      this.detailLoading = true
      this.$axios.get('http://localhost:8080/showSingleObject', {
        params: {
          name: name
        }
      })
        .then(res => {
          this.detailData = res.data
          if (this.detailData.length > 0) {
            this.sellerId = this.detailData[0].ownerId
          }
        })
        .catch(error => {
          console.error('获取详情失败:', error)
          this.$message.error('获取详情失败')
        })
        .finally(() => {
          this.detailLoading = false
        })
    },

    // 新增购买处理函数
    handleBuy (row) {
      // 检查用户是否登录
      if (!this.isLoggedIn()) {
        this.$message.error('请先登录')
        return
      }

      this.buyerId = this.getCurrentUserId()

      if (!this.buyerId) {
        this.$message.error('无法获取用户信息')
        return
      }

      if (!this.sellerId) {
        this.$message.error('无法获取卖家信息')
        return
      }

      // 构建订单对象
      const order = {
        objectId: row.objectId,
        buyerId: this.buyerId,
        sellerId: this.sellerId,
        value: row.value
      }

      console.log('发送的订单数据:', order)

      // 调用后端接口提交订单
      this.$axios.post('http://localhost:8080/insertOrder', order)
        .then(response => {
          const result = response.data
          if (result === '交易成功') {
            this.$message.success('购买成功！')
            // 购买成功后可以刷新数据或关闭弹窗
            this.detailDialogVisible = false
          } else {
            this.$message.error(result)
          }
        })
        .catch(error => {
          console.error('购买失败:', error)
          this.$message.error('购买失败，请稍后重试')
        })
    },

    postData () {
      const object = {
        type: this.type
      }
      this.$axios.post('http://localhost:8080/showObject', object)
        .then(res => {
          this.tableData = res.data
          this.startAutoScroll()
        })
    },

    // 启动自动滚动
    startAutoScroll () {
      if (this.autoScrollInterval) clearInterval(this.autoScrollInterval)

      this.autoScrollInterval = setInterval(() => {
        if (this.isMouseOverTable) return

        const container = this.$refs.tableContainer
        if (!container) return

        if (container.scrollTop + container.clientHeight >= container.scrollHeight - 10) {
          container.scrollTop = 0
        } else {
          container.scrollTop += 1
        }
      }, 50)
    },

    // 停止自动滚动
    stopAutoScroll () {
      if (this.autoScrollInterval) {
        clearInterval(this.autoScrollInterval)
        this.autoScrollInterval = null
      }
    }
  },
  mounted () {
    const container = this.$refs.tableContainer
    if (container) {
      container.addEventListener('mouseenter', () => {
        this.isMouseOverTable = true
      })
      container.addEventListener('mouseleave', () => {
        this.isMouseOverTable = false
      })
    }
  },
  beforeDestroy () {
    this.stopAutoScroll()
  },
  created () {
    this.postData()
  }
}
</script>

<style>
/* 表格容器样式 */
.table-container {
  flex: 1;
  overflow: auto;
  position: relative;
}

.el-table {
  border-color: #ed9d09 !important;
  height: 100%;
}

/* 自定义滚动条样式 */
.table-container::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-container::-webkit-scrollbar-thumb {
  border-radius: 4px;
  background-color: rgba(0, 0, 0, 0.3);
}

.table-container::-webkit-scrollbar-track {
  border-radius: 4px;
  background-color: rgba(0, 0, 0, 0.1);
}

.el-table__body td,
.el-table__header-wrapper th {
  border-color: #f6aa08 !important;
}

/* 弹窗样式优化 */
.el-dialog__header {
  background-color: #f3a183;
  padding: 15px 20px;
}

.el-dialog__title {
  color: #555;
  font-weight: bold;
}

.el-dialog__body {
  padding: 20px;
}
</style>
