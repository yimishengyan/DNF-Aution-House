<template>
  <div class="user-profile" ref="scrollContainer">
    <h2>用户信息</h2>
    <div v-if="loading" class="loading">
      <q-spinner color="primary" size="2em" />
      <p>加载中...</p>
    </div>
    <div v-else-if="error" class="error">
      <q-icon name="error" color="negative" size="2em" />
      <p>{{ error }}</p>
      <q-btn
        color="primary"
        label="重新加载"
        @click="fetchUserData"
        class="q-mt-sm"
      />
    </div>
    <div v-else-if="user" class="user-info">
      <div class="user-avatar">
        <q-avatar size="100px" color="primary" text-color="white">
          {{ user.name.charAt(0).toUpperCase() }}
        </q-avatar>
      </div>
      <div class="user-details">
        <p><strong>用户ID:</strong> {{ user.userId }}</p>
        <p><strong>用户名:</strong> {{ user.name }}</p>
        <p><strong>余额:</strong> ¥{{ user.money.toFixed(2) }}</p>
      </div>

      <div class="objects-container" ref="objectsContainer">
        <h3>我的物品</h3>
        <div v-if="objectsLoading" class="loading">
          <q-spinner color="primary" size="1em" />
          <p>加载物品中...</p>
        </div>
        <div v-else-if="objectsError" class="error">
          <q-icon name="error" color="negative" size="1em" />
          <p>{{ objectsError }}</p>
          <q-btn
            color="primary"
            label="重试"
            @click="fetchUserObjects(user.userId)"
            class="q-mt-sm"
          />
        </div>

        <div v-else-if="objects && objects.length > 0" class="objects-list">
          <el-table
            :data="filterData"
            :header-cell-style="{ background: '#f3a183', color: '#555' }"
            border
            height="100%"
          >
            <el-table-column prop="objectId" label="序号" width="150"></el-table-column>
            <el-table-column prop="name" label="名字" width="180"></el-table-column>
            <el-table-column prop="type" label="类型" width="180"></el-table-column>
            <el-table-column prop="value" label="价值" width="200"></el-table-column>
          </el-table>
        </div>
        <div v-else class="no-data">
          <q-icon name="info" color="warning" size="1em" />
          <p>暂无物品</p>
        </div>
      </div>

      <div class="action-buttons">
        <q-btn
          color="negative"
          label="注销账号"
          @click="showLogoutConfirm"
          class="q-mr-md"
        />
        <q-btn
          color="primary"
          label="充值"
          @click="showRechargeDialog"
          class="q-mr-md"
        />
        <q-btn
          color="secondary"
          label="上传物品"
          @click="showUploadDialog"
        />
      </div>
    </div>
    <div v-else class="no-data">
      <q-icon name="info" color="warning" size="2em" />
      <p>未获取到用户数据</p>
    </div>

    <q-dialog v-model="rechargeDialog">
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">账户充值</div>
        </q-card-section>

        <q-card-section>
          <q-input
            v-model.number="rechargeAmount"
            type="number"
            label="充值金额"
            min="0"
            step="0.01"
          />
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="取消" color="primary" v-close-popup />
          <q-btn flat label="确认充值" color="primary" @click="handleRecharge" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <q-dialog v-model="uploadDialog">
      <q-card style="min-width: 400px">
        <q-card-section>
          <div class="text-h6">上传物品</div>
        </q-card-section>

        <q-card-section>
          <q-form @submit="handleUpload" class="q-gutter-md">
            <q-input
              v-model="newObject.name"
              label="物品名称 *"
              :rules="[
                val => !!val || '必填项',
                val => val.length <= 10 || '不超过10个字'
              ]"
              maxlength="10"
              counter
            />

            <q-select
              v-model="newObject.type"
              :options="typeOptions"
              label="物品类型 *"
              :rules="[val => !!val || '必填项']"
              emit-value
              map-options
            />

            <q-input
              v-model.number="newObject.value"
              type="number"
              label="物品价值 *"
              :rules="[
                val => val !== null && val !== '' || '必填项',
                val => val >= 0 || '不能为负数',
                val => val <= 10000 || '不能超过10000'
              ]"
              step="0.01"
            />

            <q-input
              v-model="newObject.ownerId"
              label="所有者ID"
              readonly
              outlined
            />

            <div class="row justify-end q-mt-md">
              <q-btn
                label="取消"
                color="primary"
                flat
                v-close-popup
                class="q-mr-sm"
              />
              <q-btn
                label="提交"
                color="primary"
                type="submit"
                :disable="!isFormValid"
              />
            </div>
          </q-form>
        </q-card-section>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
export default {
  name: 'personalInfo',
  data () {
    return {
      user: null,
      loading: false,
      error: null,
      baseURL: process.env.VUE_APP_API_BASE_URL || 'http://localhost:8080',
      rechargeDialog: false,
      rechargeAmount: 0,
      uploadDialog: false,
      objects: [],
      objectsLoading: false,
      objectsError: null,
      objectColumns: [
        { name: 'objectId', label: '物品ID', field: 'objectId', sortable: true },
        { name: 'name', label: '物品名称', field: 'name', sortable: true },
        { name: 'type', label: '类型', field: 'type', sortable: true },
        { name: 'value', label: '价值', field: 'value', sortable: true }
      ],
      autoScrollInterval: null,
      isMouseOverTable: false,
      newObject: {
        name: '',
        type: '',
        value: null,
        ownerId: null
      },
      typeOptions: [
        { label: '武器', value: 'weapon' },
        { label: '饰品', value: 'jewely' },
        { label: '防具', value: 'armor' }
      ]
    }
  },
  computed: {
    filterData () {
      return this.objects || []
    },
    isFormValid () {
      return (
        this.newObject.name &&
        this.newObject.type &&
        this.newObject.value !== null &&
        this.newObject.ownerId !== null
      )
    }
  },
  created () {
    this.fetchUserData()
  },
  mounted () {
    this.startAutoScroll()
    const container = this.$refs.objectsContainer
    if (container) {
      container.addEventListener('mouseenter', () => {
        this.isMouseOverTable = true
        this.stopAutoScroll()
      })
      container.addEventListener('mouseleave', () => {
        this.isMouseOverTable = false
        this.startAutoScroll()
      })
    }
  },
  beforeDestroy () {
    this.stopAutoScroll()
  },
  methods: {
    getCookie (name) {
      const nameEQ = name + '='
      const ca = document.cookie.split(';')
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i]
        while (c.charAt(0) === ' ') c = c.substring(1, c.length)
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
      }
      return null
    },
    getUserId () {
      const cookieUserId = this.getCookie('user_id') || this.getCookie('userId')
      if (cookieUserId) return parseInt(cookieUserId)

      const sessionUserId = sessionStorage.getItem('user_id') || sessionStorage.getItem('userId')
      if (sessionUserId) return parseInt(sessionUserId)

      const localUserId = localStorage.getItem('user_id') || localStorage.getItem('userId')
      if (localUserId) return parseInt(localUserId)

      return null
    },
    async fetchUserData () {
      try {
        this.loading = true
        this.error = null

        const userId = this.getUserId()
        if (!userId) {
          throw new Error('无法获取用户ID，请先登录')
        }

        const response = await this.$axios({
          method: 'get',
          url: '/selectSingleUser',
          baseURL: this.baseURL,
          params: { userId: userId },
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }
        })

        if (response.data) {
          this.user = response.data
          localStorage.setItem('currentUser', JSON.stringify(response.data))
          this.fetchUserObjects(userId)
        } else {
          throw new Error('未获取到用户数据')
        }
      } catch (error) {
        console.error('获取用户信息失败:', error)
        this.error = `请求失败: ${error.message}`

        if (error.response) {
          if (error.response.status === 404) {
            this.error = '接口不存在，请检查路径是否正确'
          } else if (error.response.status === 500) {
            this.error = '服务器内部错误，请联系管理员'
          }
        }

        const cachedUser = localStorage.getItem('currentUser')
        if (cachedUser) {
          this.user = JSON.parse(cachedUser)
          this.error = '使用缓存数据: ' + this.error
        }
      } finally {
        this.loading = false
      }
    },
    async fetchUserObjects (userId) {
      try {
        this.objectsLoading = true
        this.objectsError = null
        this.objects = []

        const response = await this.$axios({
          method: 'get',
          url: '/showUserObject',
          baseURL: this.baseURL,
          params: { userId: userId },
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }
        })

        if (Array.isArray(response.data)) {
          this.objects = response.data
        } else if (response.data && response.data.data && Array.isArray(response.data.data)) {
          this.objects = response.data.data
        } else if (response.data && response.data.records && Array.isArray(response.data.records)) {
          this.objects = response.data.records
        } else {
          this.objects = []
        }
      } catch (error) {
        console.error('获取用户物品失败:', error)
        this.objectsError = `获取物品失败: ${error.message}`
        if (error.response) {
          if (error.response.status === 404) {
            this.objectsError = '接口不存在'
          } else if (error.response.status === 500) {
            this.objectsError = '服务器错误'
          }
        }
      } finally {
        this.objectsLoading = false
      }
    },
    showLogoutConfirm () {
      this.$q.dialog({
        title: '确认注销',
        message: '确定要注销当前账号吗？此操作将清除所有登录信息',
        cancel: true,
        persistent: true
      }).onOk(() => {
        this.logoutAccount()
      })
    },
    async logoutAccount () {
      try {
        this.loading = true
        const currentUser = JSON.parse(localStorage.getItem('currentUser'))
        const userData = {
          userId: currentUser.userId
        }
        await this.$axios({
          method: 'post',
          url: '/deleteUser',
          baseURL: this.baseURL,
          data: userData,
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }
        })
        this.$q.notify({
          type: 'positive',
          message: '账号已成功删除'
        })
        setTimeout(() => {
          this.$router.push('/login')
        }, 1500)
      } catch (error) {
        console.error('删除用户失败:', error)
        this.$q.notify({
          type: 'negative',
          message: '删除账号失败: ' + (error.response?.data?.message || error.message)
        })
      } finally {
        this.loading = false
      }
    },
    showRechargeDialog () {
      this.rechargeAmount = 0
      this.rechargeDialog = true
    },
    async handleRecharge () {
      if (this.rechargeAmount <= 0) {
        this.$q.notify({
          type: 'warning',
          message: '请输入有效的充值金额'
        })
        return
      } else if (this.rechargeAmount > 500) {
        this.$q.notify({
          type: 'warning',
          message: '充值金额不得超过500元'
        })
        return
      }
      try {
        this.loading = true
        const currentUser = JSON.parse(localStorage.getItem('currentUser'))
        const userId = currentUser.userId
        await this.$axios({
          method: 'post',
          url: '/changeMoney',
          baseURL: this.baseURL,
          params: { userId: userId, money: this.rechargeAmount },
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }
        })
        this.$q.notify({
          type: 'positive',
          message: `成功充值， ¥${this.rechargeAmount.toFixed(2)}  请刷新`
        })
        this.rechargeDialog = false
      } catch (error) {
        console.error('充值失败:', error)
        this.$q.notify({
          type: 'negative',
          message: '充值失败: ' + (error.response?.data?.message || error.message)
        })
      } finally {
        this.loading = false
      }
    },
    showUploadDialog () {
      const ownerId = this.getUserId()
      if (ownerId) {
        this.newObject = {
          name: '',
          type: '',
          value: null,
          ownerId: ownerId
        }
        this.uploadDialog = true
      } else {
        this.$q.notify({
          type: 'negative',
          message: '无法获取用户ID，请重新登录'
        })
      }
    },
    async handleUpload () {
      try {
        await this.$axios({
          method: 'post',
          url: '/insertObject',
          baseURL: this.baseURL,
          data: this.newObject,
          headers: {
            'Content-Type': 'application/json'
          }
        })

        this.$q.notify({
          type: 'positive',
          message: '物品上传成功!'
        })

        this.uploadDialog = false
        this.fetchUserObjects(this.user.userId)
      } catch (error) {
        console.error('上传失败:', error)
        this.$q.notify({
          type: 'negative',
          message: `上传失败: ${error.response?.data?.message || error.message}`
        })
      }
    },
    startAutoScroll () {
      if (this.autoScrollInterval) clearInterval(this.autoScrollInterval)
      this.autoScrollInterval = setInterval(() => {
        if (this.isMouseOverTable) return
        const container = this.$refs.objectsContainer
        if (!container) return
        if (container.scrollTop + container.clientHeight >= container.scrollHeight - 10) {
          container.scrollTop = 0
        } else {
          container.scrollTop += 1
        }
      }, 50)
    },
    stopAutoScroll () {
      if (this.autoScrollInterval) {
        clearInterval(this.autoScrollInterval)
        this.autoScrollInterval = null
      }
    }
  }
}
</script>

<style scoped>
html {
  scroll-behavior: smooth;
}

.user-profile {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  height: 90vh;
  overflow-y: auto;
}

.user-avatar {
  display: flex;
  justify-content: center;
  margin: 20px 0;
}

.user-details {
  background: #f9f9f9;
  padding: 20px;
  border-radius: 6px;
  margin-bottom: 20px;
}

.objects-container {
  max-height: 100vh;
  overflow: auto;
  margin: 20px 0;
  padding: 15px;
  background: #f5f5f5;
  border-radius: 8px;
}

.objects-container::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

.objects-container::-webkit-scrollbar-thumb {
  background-color: #999;
  border-radius: 3px;
}

.objects-container::-webkit-scrollbar-track {
  background-color: #f0f0f0;
  border-radius: 3px;
}

.action-buttons {
  display: flex;
  justify-content: center;
  margin: 30px 0;
}
</style>
