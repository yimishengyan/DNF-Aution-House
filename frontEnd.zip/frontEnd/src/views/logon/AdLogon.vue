<template>
  <div class="flex justify-center items-center" style="height: 100vh">
    <div class="row base-card-shadow" style="width: 60vw;min-width: 300px">
      <div class="col-6 flex justify-center items-center " v-show="$q.screen.gt.sm">
        <q-img
          :src="this.$PUBLIC_PATH + 'data/logo.jpg'"
        />
      </div>
      <q-separator vertical inset v-if="$q.screen.gt.sm"/>
      <div class="col flex justify-center items-center">
        <q-card square style="min-width: 290px;height: 100%; width: 60%;" class="no-shadow">
          <q-card-section align="center">
            <h3 class="text-uppercase">管理员登录</h3>
            <!-- 用户名 -->
            <q-input class="logon-input"
               clearable
               standout="bg-cyan text-white"
               bottom-slots
               v-model="username"
               label="账号"
               :error="usernameError"
               error-message="用户名不能为空"
            >
              <template v-slot:prepend>
                <q-icon name="account_circle"/>
              </template>
            </q-input>
            <!-- 密码 -->
            <q-input class="logon-input"
               standout="bg-cyan text-white"
               bottom-slots
               v-model="password"
               label="密码"
               :type="isPwd ? 'password' : 'text'"
               :error="passwordError"
               error-message="密码不能为空"
            >
              <template v-slot:prepend>
                <q-icon name="vpn_key"/>
              </template>
              <template v-slot:append>
                <q-icon
                  :name="isPwd ? 'visibility_off' : 'visibility'"
                  class="cursor-pointer"
                  @click="isPwd = !isPwd"
                />
              </template>
            </q-input>

            <!-- 登录按钮 -->
            <q-btn
              :loading="loading"
              class="logon-btn bg-logon-card-input"
              text-color="white"
              unelevated
              @click="login"
            >登 录 系 统</q-btn>
            <div class="row justify-between mt-2">
              <q-btn
                class="logon-btn bg-logon-register"
                text-color="white"
                unelevated
                style="font-size: small;"
                @click="goToRegister"
              >我要注册</q-btn>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AdLogin',
  data () {
    return {
      isPwd: true,
      username: '',
      password: '',
      usernameError: false,
      passwordError: false,
      loading: false
    }
  },
  methods: {
    validateForm () {
      this.usernameError = !this.username.trim()
      this.passwordError = !this.password.trim()
      return !(this.usernameError || this.passwordError)
    },
    login () {
      this.loading = !this.loading
      if (!this.validateForm()) return
      this.loading = true
      // 准备用户数据
      const userData = {
        name: this.username,
        password: this.password
      }
      // 发送登录请求
      this.$axios.post('http://localhost:8080/selectAdministrator', userData)
        .then(response => {
          const result = response.data
          switch (result) {
            case '登录成功':
              // 登录成功，存储token和用户角色
              sessionStorage.setItem('access_token', '972784674')
              sessionStorage.setItem('user_role', 'editor')
              setTimeout(() => {
                this.$router.push('/').then(e => {
                  this.$q.notify({
                    icon: 'insert_emoticon',
                    message: 'hi，帅哥美女 欢迎回来',
                    color: 'green',
                    position: 'top',
                    timeout: 1500
                  })
                }
                )
              })
              break
            case '无该管理员':
              this.$q.notify({
                icon: 'error',
                message: '无该管理员',
                color: 'red',
                position: 'top',
                timeout: 3000
              })
              break
            case '登陆失败':
              this.$q.notify({
                icon: 'error',
                message: '密码错误',
                color: 'red',
                position: 'top',
                timeout: 3000
              })
              break
            default:
              this.$q.notify({
                icon: 'error',
                message: '未知错误，请重试',
                color: 'red',
                position: 'top',
                timeout: 3000
              })
          }
        })
        .catch(error => {
          console.error('登录请求出错:', error)
          this.$q.notify({
            icon: 'error',
            message: '服务器错误，请稍后再试',
            color: 'red',
            position: 'top',
            timeout: 3000
          })
        })
        .finally(() => {
          this.loading = false
        })
    },
    goToRegister () {
      this.$router.push({ name: 'AdRegister.vue' })
    }
  }
}
</script>

<style scoped>
  .logon-btn {
    font-size: large;
    margin-top: 0px;
    margin-bottom: 20px;
    width: 100%;
  }

  .bg-logon-card-input {
    background: linear-gradient(to right, #36d1dc 1%, #5b86e5 99%);
    transition: all 0.3s ease-in-out;
    background-size: 200% auto;
  }
  .bg-logon-register{
    background: linear-gradient(to right, #36afc4 1%, #5b6da8 99%);
    transition: all 0.3s ease-in-out;
    background-size: 200% auto;
  }
  .bg-logon-card-input:hover,
  .bg-logon-register:hover {
    background-position: right center;
    box-shadow: 0 12px 20px -11px #5b86e5;
  }
</style>
