<template>
  <div class="flex justify-center items-center" style="height: 100vh">
    <div class="row base-card-shadow" style="width: 60vw;min-width: 300px">
      <q-separator vertical inset v-if="$q.screen.gt.sm"/>
      <div class="col flex justify-center items-center">
        <q-card square style="min-width: 290px;height: 100%; width: 60%;" class="no-shadow">
          <q-card-section align="center">
            <h3 class="text-uppercase">管理员注册</h3>
            <!-- 用户名 -->
            <q-input class="logon-input"
               clearable
               standout="bg-cyan text-white"
               bottom-slots
               v-model="username"
               label="用户名"
               :error="usernameError"
               error-message="用户名不能为空"
            >
              <template v-slot:prepend>
                <q-icon name="account_circle"/>
              </template>
            </q-input>
            <!-- 密码 -->
            <q-input class="logon-input"
               standout="bg-cyan text-white"
               bottom-slots
               v-model="password"
               label="密码"
               :type="isPwd ? 'password' : 'text'"
               :error="passwordError"
               error-message="密码不能为空"
            >
              <template v-slot:prepend>
                <q-icon name="vpn_key"/>
              </template>
              <template v-slot:append>
                <q-icon
                  :name="isPwd ? 'visibility_off' : 'visibility'"
                  class="cursor-pointer"
                  @click="isPwd = !isPwd"
                />
              </template>
            </q-input>
            <!-- 确认密码 -->
            <q-input class="logon-input"
               standout="bg-cyan text-white"
               bottom-slots
               v-model="confirmPassword"
               label="确认密码"
               :type="isPwd ? 'password' : 'text'"
               :error="confirmPasswordError"
               error-message="两次输入的密码不一致"
            >
              <template v-slot:prepend>
                <q-icon name="vpn_key"/>
              </template>
              <template v-slot:append>
                <q-icon
                  :name="isPwd ? 'visibility_off' : 'visibility'"
                  class="cursor-pointer"
                  @click="isPwd = !isPwd"
                />
              </template>
            </q-input>

            <!-- 注册按钮 -->
            <q-btn
              :loading="loading"
              class="logon-btn bg-logon-card-input"
              text-color="white"
              unelevated
              @click="register"
            >立即注册</q-btn>
            <div class="mt-4">
              <span class="text-grey cursor-pointer" @click="goToLogin">已有账号？返回登录</span>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AdRegister',
  data () {
    return {
      isPwd: true,
      username: '',
      password: '',
      confirmPassword: '',
      usernameError: false,
      passwordError: false,
      confirmPasswordError: false,
      loading: false
    }
  },
  methods: {
    validateForm () {
      this.usernameError = !this.username.trim()
      this.passwordError = !this.password.trim()
      this.confirmPasswordError = this.password !== this.confirmPassword
      return !(this.usernameError || this.passwordError || this.confirmPasswordError)
    },
    register () {
      if (!this.validateForm()) return
      this.loading = true
      // 准备用户数据
      const userData = {
        name: this.username,
        password: this.password
      }
      // 发送注册请求
      this.$axios.post('http://localhost:8080/insertAdministrator', userData)
        .then(response => {
          const result = response.data
          if (result === '创建成功') {
            this.$q.notify({
              icon: 'check_circle',
              message: '注册成功，请登录',
              color: 'green',
              position: 'top',
              timeout: 1500
            })
            // 注册成功后跳转到登录页面
            setTimeout(() => {
              this.$router.push('/Adlogon')
            }, 1500)
          } else {
            // 注册失败提示
            this.$q.notify({
              icon: 'error',
              message: result,
              color: 'red',
              position: 'top',
              timeout: 3000
            })
          }
        })
        .catch(error => {
          console.error('注册请求出错:', error)
          this.$q.notify({
            icon: 'error',
            message: '服务器错误，请稍后再试',
            color: 'red',
            position: 'top',
            timeout: 3000
          })
        })
        .finally(() => {
          this.loading = false
        })
    },
    goToLogin () {
      this.$router.push('/Adlogon')
    }
  }
}
</script>

<style scoped>
  .logon-btn {
    font-size: large;
    margin-top: 0px;
    margin-bottom: 20px;
    width: 100%;
  }

  .bg-logon-card-input {
    background: linear-gradient(to right, #36d1dc 1%, #5b86e5 99%);
    transition: all 0.3s ease-in-out;
    background-size: 200% auto;
  }
  .bg-logon-card-input:hover {
    background-position: right center;
    box-shadow: 0 12px 20px -11px #5b86e5;
  }
</style>
